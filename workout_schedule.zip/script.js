function updateGraph() {
    const pmSquats = parseFloat(document.getElementById("pm_squats").value);
    const pmDeadlift = parseFloat(document.getElementById("pm_deadlift").value);
    const pmBench = parseFloat(document.getElementById("pm_bench").value);
    const exerciseType = document.getElementById("exercise_type").value;

    // Проверка на корректность введённых данных
    if (isNaN(pmSquats) || isNaN(pmDeadlift) || isNaN(pmBench)) {
        alert("Пожалуйста, введите корректные значения для всех ПМ!");
        return;
    }

    const tableBody = document.querySelector("#graph tbody");
    tableBody.innerHTML = ""; // Очистить текущую таблицу

    const weeks = 16;
    let percent = 75;
    let volume = 0;
    let tonnage = 0;
    const sets = 5; // Количество подходов
    const reps = 5; // Количество повторений в каждом подходе

    for (let week = 1; week <= weeks; week++) {
        // Тип тренировки
        let workoutType = "";
        if (week % 3 === 1) {
            workoutType = "Тяжёлая";
            percent = 85; // Тяжёлая тренировка (85%)
        } else if (week % 3 === 2) {
            workoutType = "Средняя";
            percent = 75; // Средняя тренировка (75%)
        } else {
            workoutType = "Лёгкая";
            percent = 65; // Лёгкая тренировка (65%)
        }

        // Выбор упражнения
        let selectedWeight = 0;
        let exerciseName = "";

        if (exerciseType === "squats") {
            selectedWeight = pmSquats * percent / 100;
            exerciseName = "Приседания";
        } else if (exerciseType === "deadlift") {
            selectedWeight = pmDeadlift * percent / 100;
            exerciseName = "Тяга в наклоне";
        } else if (exerciseType === "bench") {
            selectedWeight = pmBench * percent / 100;
            exerciseName = "Жим лёжа";
        }

        // Объём работы (кг) и тоннаж
        volume = selectedWeight * reps; // 5 повторений
        tonnage = volume * sets; // 5 подходов

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${week}</td>
            <td>${workoutType}</td>
            <td>${exerciseName}</td>
            <td>${percent}%</td>
            <td>${selectedWeight.toFixed(1)}</td>
            <td>${sets} x ${reps}</td>
            <td>${volume.toFixed(1)}</td>
            <td>${tonnage.toFixed(1)}</td>
        `;
        tableBody.appendChild(row);
    }
}

// Initial graph update
updateGraph();